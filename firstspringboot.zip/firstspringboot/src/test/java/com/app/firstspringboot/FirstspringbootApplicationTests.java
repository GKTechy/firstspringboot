package com.app.firstspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
